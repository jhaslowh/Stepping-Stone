/** Player Structure */
function Player(x,y){ 
  // Location of player 
  this.x = x;
  this.y = y;
  this.width = 50;
  this.height = 24;
}

/** Update player state */
Player.prototype.update = function(){
  // TODO 
}

/** Draw player to screen */
Player.prototype.draw = function (){
  // TODO 
}